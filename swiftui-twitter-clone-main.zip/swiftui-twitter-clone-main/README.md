# Twitter clone with SwiftUI

# Screenshots

![Simulator Screen Shot - iPhone 11 - 2021-02-14 at 20 02 37](https://user-images.githubusercontent.com/41873800/107885211-d234b800-6ead-11eb-8088-a1054d21c5cc.png)
![Simulator Screen Shot - iPhone 11 - 2021-02-14 at 20 05 25](https://user-images.githubusercontent.com/41873800/107885213-d365e500-6ead-11eb-8ef0-b6bab7b0ce31.png)

